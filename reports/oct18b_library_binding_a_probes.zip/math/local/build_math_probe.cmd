@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars32.bat" > local\math_probe_toolchain.log
if errorlevel 1 exit /b %errorlevel%
cl /nologo /std:c++17 /W4 /WX /O2 /MD /EHsc /fp:strict /arch:SSE2 /Gy /Iinclude /Ilocal local\math_conversion_probe.cpp src\native_render_batch_keys.cpp /Fe:local\math_conversion_probe.exe /Fo:local\ /link /MANIFEST:EMBED /OPT:REF
if errorlevel 1 exit /b %errorlevel%
local\math_conversion_probe.exe > local\math_conversion_probe_result.txt
exit /b %errorlevel%
