import hashlib
import json
import struct
from pathlib import Path

binary = Path('I:/SteamLibrary/steamapps/common/Battlestations Pacific/battlestationspacific.exe')
data = binary.read_bytes()
pe = struct.unpack_from('<I', data, 0x3c)[0]
sections, optional_size = struct.unpack_from('<H', data, pe+6)[0], struct.unpack_from('<H', data, pe+20)[0]
table = pe + 24 + optional_size
start, size = 0xbf7420, 0xab
for i in range(sections):
    off = table + i*40
    virtual_size, rva, raw_size, raw = struct.unpack_from('<IIII', data, off+8)
    if rva <= start-0x400000 < rva+raw_size:
        code = data[raw+start-0x400000-rva:raw+start-0x400000-rva+size]
        break
else:
    raise RuntimeError('conversion code not disk-backed')
assert len(code) == size and code[:6] == bytes.fromhex('833da4ee0901')
live_hex = '''
83 3d a4 ee 09 01 00 74 2d 55 8b ec 83 ec 08 83
e4 f8 dd 1c 24 f2 0f 2c 04 24 c9 c3 83 3d a4 ee
09 01 00 74 11 83 ec 04 d9 3c 24 58 66 83 e0 7f
66 83 f8 7f 74 d3 55 8b ec 83 ec 20 83 e4 f0 d9
c0 d9 54 24 18 df 7c 24 10 df 6c 24 10 8b 54 24
18 8b 44 24 10 85 c0 74 3c de e9 85 d2 79 1e d9
1c 24 8b 0c 24 81 f1 00 00 00 80 81 c1 ff ff ff
7f 83 d0 00 8b 54 24 14 83 d2 00 eb 2c d9 1c 24
8b 0c 24 81 c1 ff ff ff 7f 83 d8 00 8b 54 24 14
83 da 00 eb 14 8b 54 24 14 f7 c2 ff ff ff 7f 75
b8 d9 5c 24 18 d9 5c 24 18 c9 c3
'''
assert code == bytes.fromhex(live_hex), 'guarded Ghidra bytes differ from installed PE'
Path('local/math_conversion_bytes.hpp').write_text(
    'static const unsigned char original_conversion[] = {' + ','.join(hex(b) for b in code) + '};\n')
receipt = {'binary': str(binary), 'binary_sha256': hashlib.sha256(data).hexdigest(),
           'start': '00bf7420', 'size': size, 'sha256': hashlib.sha256(code).hexdigest(),
           'guarded_ghidra_bytes_equal': True,
           'relocations': [{'offset': 2, 'original': '0109eea4', 'replacement': 'probe dispatch_mode'}]}
Path('local/math_conversion_bytes.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps(receipt, indent=2))
