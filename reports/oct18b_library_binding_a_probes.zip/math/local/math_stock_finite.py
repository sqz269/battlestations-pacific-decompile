import hashlib, json, struct
from pathlib import Path
from capstone import Cs, CS_ARCH_X86, CS_MODE_32

binary = Path('C:/Windows/SysWOW64/ucrtbase.dll')
data = binary.read_bytes()
pe = struct.unpack_from('<I', data, 0x3c)[0]
sections = struct.unpack_from('<H', data, pe+6)[0]
optional_size = struct.unpack_from('<H', data, pe+20)[0]
optional = pe+24
assert struct.unpack_from('<H', data, optional)[0] == 0x10b
base = struct.unpack_from('<I', data, optional+28)[0]
table = optional+optional_size
def offset(rva):
    for i in range(sections):
        o = table+i*40
        size, section_rva, raw_size, raw = struct.unpack_from('<IIII', data, o+8)
        if section_rva <= rva < section_rva+raw_size:
            return raw+rva-section_rva
    raise RuntimeError(hex(rva))
def u32(rva): return struct.unpack_from('<I', data, offset(rva))[0]
export_rva, export_size = struct.unpack_from('<II', data, optional+96)
exp = offset(export_rva)
count, functions, names, ordinals = struct.unpack_from('<IIII', data, exp+24)
for i in range(count):
    name_offset = offset(u32(names+i*4))
    name = data[name_offset:data.index(0, name_offset)].decode('ascii')
    if name == '_finite':
        ordinal = struct.unpack_from('<H', data, offset(ordinals+i*2))[0]
        target = u32(functions+ordinal*4)
        break
else:
    raise RuntimeError('_finite export not found')
assert not export_rva <= target < export_rva+export_size, 'forwarded export'
blob = data[offset(target):offset(target)+96]
lines = []
returns = 0
for insn in Cs(CS_ARCH_X86, CS_MODE_32).disasm(blob, base+target):
    lines.append(f'{insn.address:08x}: {insn.mnemonic} {insn.op_str}')
    if insn.mnemonic == 'ret':
        returns += 1
        if returns == 2: break
receipt = {'binary': str(binary), 'sha256': hashlib.sha256(data).hexdigest(),
           'export': '_finite', 'rva': hex(target), 'listing': lines}
Path('local/math_stock_finite.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps(receipt, indent=2))
