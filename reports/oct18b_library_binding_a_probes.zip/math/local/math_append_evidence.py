import json
import subprocess
import sys
from pathlib import Path

inventory = json.loads(Path('J:/PROG/battlestations-pacific-decompile-oct18b-libA/local/oct18b_library_binding_coverage_raw.json').read_text())
names = {row['address']: row['name'] for row in inventory['functions']}
notes = {
    '00bf701a': 'atan2 x87 ST1=y/ST0=x; heading game call 00414EB6 verified. Behaviour-sensitive boundary: raw floats without finite/nonzero guard; current-stock parity pending.',
    '00bf7030': 'sqrt game call 00419491 verified after native float sum spill. Behaviour-sensitive exceptional/control-word boundary, current-stock parity pending; preserve existing system_camera_axes and legacy_crt_math source pins.',
    '00bf7420': 'Behaviour-sensitive mode conversion reads actual0109EEA4; nonzero FSTP64/CVTTSD2SI signed32, zero BF7456 signed64 low32. New focused probe:208 original/source comparisons pass;50 mode low32 differences, including extended1-2^-54 atCW037F. Existing native_render_batch_keys pin retained.',
    '00bf7456': 'x87 signed64 truncate/correction hardware helper; game call B51EB1 consumes lowEAX from float entry+14h. New focused208-comparison dispatcher/source probe passed, including EDX:EAX and FPstatus on this route. Not interchangeable with signed32 cast outside constrained domain.',
    '00bf8490': 'atan role supported by Lua math_atan and native FLD1/FPATAN. Game helper0042CF10 call0042CF82 has finite ratio domain[-1,1] but no NaN exclusion. Behaviour-sensitive boundary, stock parity pending.',
    '00bf857a': 'fmod role confirmed; game angle call0085ABBD uses incoming float and promoted-float2pi divisor. Finite identical-operand value binding is qualified; no whole-caller finite guard established. Behaviour-sensitive exceptional/environment obligation, parity pending.',
    '00bf85b0': 'floor role confirmed by Lua and game004396FB; stack double with callerADD ESP,8. Same finite binary64 floor value is exact; no finite guard establishes whole binding. Behaviour-sensitive exception/environment parity pending. Broad Ghidra body throughC0F464 is not contiguous floor credit.',
    '00bf9940': 'acos role confirmed by Lua math_acos callA617CD and game0059F98D. x87/SSE dispatch and raw stored float input; behaviour-sensitive precision/exception boundary, stock parity pending.',
    '00bfa020': 'tan role confirmed by Lua math_tan and game0060C557; float-spilled half camera+80h with no finite/pole-distance guard. Behaviour-sensitive input/FP environment boundary, stock parity pending.',
    '00bfa4ec': 'Bind-safe scalar finite predicate for same readable binary64 bytes: integer exponent!=7FF, exact0/1, noFP/errno/TLS/global. Installed x86ucrtbase _finite RVA6C8C0 has equivalent integer-only two-return body. Upstream camera arithmetic/spills not included.',
    '00bfa7b0': 'ceil role confirmed by LuaA61883 and exact gameB84106. Same finite binary64 ceil value is exact, but no whole-caller finite/nonzero-scale guard established. Behaviour-sensitive exceptional/environment obligation, parity pending.',
    '00bfa910': 'log role confirmed by LuaA619FD and game0074F4AE/C5; first input float-spilled sqrt(settings+40Ch), second native double2. No strict-positive first-input guard. Behaviour-sensitive precision/domain/FP environment boundary, stock parity pending.',
    '00bfe5e0': 'sin wrapper and FSIN/FPREM1 fallback inspected. Snapshot callerA61670 and rawcallA6167D only; no native-game direct or absolute target hits. Script-callable; not classified globally unreachable or stock-equivalent.',
    '00bfe740': 'cos wrapper and FCOS/FPREM1 fallback inspected. Snapshot callerA616D0 and rawcallA616DD only; no native-game direct or absolute target hits. Script-callable; not classified globally unreachable or stock-equivalent.',
    '00bfe870': 'asin role confirmed by Lua math_asin and native float adapter00401190 call00401194; no[-1,1]guard in adapter. Behaviour-sensitive domain/FP environment boundary, stock parity pending; adapter call is static evidence, not observed runtime reach.',
    '00bfeb10': 'Behaviour-sensitive pow gamma callB21A57: float basei/255, exponent1/(2*normalized gamma), including zero/NaN obligations. Existing complete dispatch/fallback/SSE2 and native_renderer_gamma pins retained. Current-stock numerical parity pending; no new vendor reconstruction requested.',
    '00bfeda0': 'log10 root has Lua math_log10 directcallA61A2D only in inspected inventory; no native-game direct or absolute target hits. Script-callable, not a game-native classified family or global-unreachability proof.',
    '00bfeeec': 'exp role confirmed by Lua math_exp and Gaussian gamecallB4CEC6; ordinary exponent<=0 but rho=0/nonfinite not excluded by routine. Behaviour-sensitive exceptional/precision/FP environment obligation, stock parity pending.',
    '00c19260': 'Existing qualified x87 pow wrapper/source pin retained. IncomingST0 exponent/ST1 base; original FXCH/FSTPs under current controls precede SSE2core. Internal support, not separately counted game-native direct family; no numerical proof added.',
    '00c19279': 'Existing complete SSE2pow source/static pin retained; original table/algorithm equivalence evidence is distinct from stock numeric parity or gameplay. Internal support excluded from direct-family tally.',
    '00c27489': 'Existing qualified sqrt error support pin retained, including original32-byte exception and112-byte FPIEEE continuation layouts, owning errno and bypass state. Conditional library support, not extra direct-game family or observed-game error-path claim.',
    '00c28548': 'Existing rawFRNDINT current-x87-state source pin noted; internal support only. No direct native-game caller established in inspected inventory, and no standalone stock rounding admission.',
}
for address, note in notes.items():
    evidence = '[OCT18B library binding math audit] ' + note + ' See docs/OCT18B_LIBRARY_BINDING_A_MATH.md; root absolute-dword scan hits=0. No Ghidra name/comment mutation.'
    result = subprocess.run([sys.executable, 'tools/bsp.py', 'ledger', 'add-name', address,
        names[address], '--evidence', evidence, '--append-evidence'], text=True, capture_output=True)
    if result.returncode:
        print(result.stdout, result.stderr)
        raise SystemExit(result.returncode)
    print(address, result.stdout.strip(), flush=True)
