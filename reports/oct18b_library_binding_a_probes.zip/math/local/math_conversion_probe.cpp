#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <xmmintrin.h>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include "bsp/native_render_batch_keys.hpp"
#include "math_conversion_bytes.hpp"

struct Result { unsigned low, high, sw, mxcsr; };
static volatile unsigned dispatch_mode;
static void* native_code;

static Result invoke(void* entry, const double* value, const double* extra,
                     unsigned short cw) {
    Result result{};
    unsigned eax_bits, edx_bits;
    unsigned short sw;
    _mm_setcsr(0x1f80);
    __asm {
        fninit
        fldcw cw
        mov eax, value
        fld qword ptr [eax]
        mov eax, extra
        fld qword ptr [eax]
        faddp st(1), st(0)
        lea ecx, dispatch_mode
        mov eax, entry
        call eax
        mov eax_bits, eax
        mov edx_bits, edx
        fnstsw sw
    }
    result.low = eax_bits;
    result.high = edx_bits;
    result.sw = sw;
    result.mxcsr = _mm_getcsr();
    return result;
}

int main() {
    native_code = VirtualAlloc(nullptr, sizeof(original_conversion),
        MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    if (!native_code) return 2;
    std::memcpy(native_code, original_conversion, sizeof(original_conversion));
    const auto pointer = reinterpret_cast<std::uintptr_t>(&dispatch_mode);
    // Sole relocation: original CMP DWORD PTR [0109EEA4],0 data address.
    std::memcpy(static_cast<unsigned char*>(native_code) + 2, &pointer, 4);
    FlushInstructionCache(GetCurrentProcess(), native_code, sizeof(original_conversion));
    const double values[] = {0.0, -0.0, 1.75, -1.75, 2147483647.0,
        2147483648.0, 2147483649.0, -2147483649.0, 4294967295.0,
        1e20, 1.0, 0.0, 0.0};
    double inputs[13];
    std::memcpy(inputs, values, sizeof(values));
    const std::uint64_t special[] = {0x7ff8000000000001ULL, 0x7ff0000000000000ULL};
    std::memcpy(&inputs[11], &special[0], 8);
    std::memcpy(&inputs[12], &special[1], 8);
    const unsigned short controls[] = {0x027f, 0x067f, 0x0a7f, 0x0e7f,
        0x037f, 0x077f, 0x0b7f, 0x0f7f};
    unsigned comparisons = 0, failures = 0, differences = 0;
    for (const auto cw : controls) {
        for (unsigned i = 0; i < 13; ++i) {
            const double extra = i == 10 ? -0x1p-54 : 0.0;
            Result selected[2];
            for (unsigned mode = 0; mode < 2; ++mode) {
                dispatch_mode = mode;
                const auto original = invoke(native_code, &inputs[i], &extra, cw);
                const auto source = invoke(reinterpret_cast<void*>(
                    &bsp::native_crt_truncate_st0_00bf7420), &inputs[i], &extra, cw);
                selected[mode] = original;
                ++comparisons;
                if (original.low != source.low || original.sw != source.sw ||
                    original.mxcsr != source.mxcsr ||
                    (mode == 0 && original.high != source.high)) ++failures;
            }
            if (selected[0].low != selected[1].low) {
                ++differences;
                if (cw == 0x027f || (cw == 0x037f && i == 10))
                    std::printf("cw=%04x input=%u x87=%08x sse=%08x x87sw=%04x ssesw=%04x x87mx=%04x ssemx=%04x\n",
                        cw, i, selected[0].low, selected[1].low,
                        selected[0].sw, selected[1].sw, selected[0].mxcsr, selected[1].mxcsr);
            }
        }
    }
    __asm fninit
    _mm_setcsr(0x1f80);
    VirtualFree(native_code, 0, MEM_RELEASE);
    std::printf("original_source_comparisons=%u failures=%u mode_low32_differences=%u\n",
        comparisons, failures, differences);
    return failures ? 1 : 0;
}
