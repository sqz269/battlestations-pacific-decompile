@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvars32.bat" > nul
if errorlevel 1 exit /b %errorlevel%
mt -nologo -inputresource:local\math_conversion_probe.exe;#1 -out:local\math_conversion_probe.manifest
if errorlevel 1 exit /b %errorlevel%
cl /Bv > local\math_probe_compiler.txt 2>&1
dumpbin /headers local\math_conversion_probe.exe > local\math_probe_headers.txt
exit /b %errorlevel%
