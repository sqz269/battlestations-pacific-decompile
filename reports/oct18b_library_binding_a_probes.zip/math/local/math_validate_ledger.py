import json
import subprocess
from pathlib import Path

wanted = set('00bf701a 00bf7030 00bf7420 00bf7456 00bf8490 00bf857a 00bf85b0 00bf9940 00bfa020 00bfa4ec 00bfa7b0 00bfa910 00bfe5e0 00bfe740 00bfe870 00bfeb10 00bfeda0 00bfeeec 00c19260 00c19279 00c27489 00c28548'.split())
def parse(text):
    return {row['address']: row for row in map(json.loads, text.splitlines())}
changed = []
for path in ('config/names/00bf0000.jsonl', 'config/names/00c10000.jsonl', 'config/names/00c20000.jsonl'):
    old = parse(subprocess.check_output(['git', 'show', 'HEAD:'+path], text=True))
    new = parse(Path(path).read_text())
    assert old.keys() <= new.keys()
    for address, record in new.items():
        if old.get(address) != record:
            changed.append(address)
            assert address in wanted, address
            if address in old:
                assert old[address]['name'] == record['name'], address
                assert old[address]['evidence'] in record['evidence'], address
assert set(changed) == wanted, set(changed)^wanted
print('changed_records=22 names_preserved=True earlier_evidence_preserved=True')
