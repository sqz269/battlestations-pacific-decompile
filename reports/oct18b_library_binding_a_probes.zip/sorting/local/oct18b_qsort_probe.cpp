#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iterator>
#include <utility>
#include <vector>
#include "bsp/native_qsort_kernel.hpp"

struct Item { float key; int id; };
static std::vector<std::pair<int,int>> trace;
static int compare_mode;
static int __cdecl compare(const void* a, const void* b) {
    const auto& x = **static_cast<Item* const*>(a);
    const auto& y = **static_cast<Item* const*>(b);
    trace.emplace_back(x.id,y.id);
    if (compare_mode == 0) return static_cast<int>(y.key-x.key);
    return (y.key>x.key)-(y.key<x.key);
}
static int __cdecl compare_context(void* context, const void* a, const void* b) {
    if (*static_cast<int*>(context) != 0x627370) std::abort();
    return compare(a,b);
}

int main(int argc,char** argv) {
    if (argc != 2) return 2;
    std::ifstream f(argv[1],std::ios::binary);
    std::vector<unsigned char> image((std::istreambuf_iterator<char>(f)),{});
    if (image.size()<0x1000) return 3;
    auto* dos=reinterpret_cast<IMAGE_DOS_HEADER*>(image.data());
    auto* nt=reinterpret_cast<IMAGE_NT_HEADERS32*>(image.data()+dos->e_lfanew);
    if(nt->Signature!=IMAGE_NT_SIGNATURE || nt->FileHeader.Machine!=IMAGE_FILE_MACHINE_I386) return 4;
    constexpr unsigned start=0x00bfbe50, end=0x00bfc5f7;
    auto* code=static_cast<unsigned char*>(VirtualAlloc(nullptr,end-start,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE));
    if(!code) return 5;
    auto* sec=IMAGE_FIRST_SECTION(nt);
    bool copied=false;
    for(unsigned i=0;i<nt->FileHeader.NumberOfSections;++i) {
        const auto va=nt->OptionalHeader.ImageBase+sec[i].VirtualAddress;
        if(start>=va && end<=va+sec[i].SizeOfRawData) {
            std::memcpy(code,image.data()+sec[i].PointerToRawData+start-va,end-start);
            copied=true;
        }
    }
    if(!copied) return 6;
    DWORD previous;
    if(!VirtualProtect(code,end-start,PAGE_EXECUTE_READ,&previous)) return 7;
    FlushInstructionCache(GetCurrentProcess(),code,end-start);
    using Sort=void(__cdecl*)(void*,size_t,size_t,int(__cdecl*)(const void*,const void*));
    using SortS=void(__cdecl*)(void*,size_t,size_t,int(__cdecl*)(void*,const void*,const void*),void*);
    const auto original=reinterpret_cast<Sort>(code+0x00bfc350-start);
    const auto original_s=reinterpret_cast<SortS>(code+0x00bfbf10-start);
    float keys[]={1.5f,1.75f,0.25f,1.25f,2.0f,2.25f,0.0f,0.75f,1.0f,2.5f,0.5f,1.5f};
    Item items[12];
    for(int i=0;i<12;++i) items[i]={keys[i],i};
    int failures=0,cases=0;
    for(size_t count: {size_t(7),size_t(12)}) for(int mode=0;mode<2;++mode) {
        compare_mode=mode;
        std::vector<Item*> a,b,c;
        for(size_t i=0;i<count;++i) a.push_back(items+i);
        b=c=a;
        trace.clear();
        int context=0x627370;
        if(mode==0) original(a.data(),count,4,compare);
        else original_s(a.data(),count,4,compare_context,&context);
        const auto original_trace=trace;
        trace.clear();
        if(mode==0) std::qsort(b.data(),count,4,compare);
        else ::qsort_s(b.data(),count,4,compare_context,&context);
        const auto stock_trace=trace;
        const bool stock_ok=a==b && original_trace==stock_trace;
        bool projection_ok=true;
        if(mode==0) {
            trace.clear();
            bsp::sort_valid_native_bytes_00bfc350(c.data(),static_cast<unsigned>(count),4,compare);
            projection_ok=a==c && original_trace==trace;
        }
        ++cases;
        if(!stock_ok || !projection_ok) ++failures;
        std::printf("%s count=%zu stock_output_trace=%s existing_projection=%s calls=%zu order=",mode?"qsort_s":"qsort",count,stock_ok?"match":"DIFF",mode?"not-tested":projection_ok?"match":"DIFF",original_trace.size());
        for(auto* p:a) std::printf("%d,",p->id);
        std::puts("");
    }
    VirtualFree(code,0,MEM_RELEASE);
    std::printf("cases=%d failures=%d\n",cases,failures);
    return failures?1:0;
}
