import hashlib
import json
import os
from pathlib import Path
import subprocess

root=Path(__file__).resolve().parents[1]
out=root/'local/output/oct18b-qsort-probe'
out.mkdir(parents=True,exist_ok=True)
vswhere=Path(os.environ['ProgramFiles(x86)'])/'Microsoft Visual Studio/Installer/vswhere.exe'
vs=Path(subprocess.check_output([str(vswhere),'-latest','-products','*','-requires','Microsoft.VisualStudio.Component.VC.Tools.x86.x64','-property','installationPath'],text=True).strip())
rsp=out/'qsort-probe.rsp'
rsp.write_text('\n'.join(['/nologo','/std:c++17','/EHsc','/MD','/O2','/W4','/WX',f'/I"{root / "include"}"',f'"{root / "local/oct18b_qsort_probe.cpp"}"',f'"{root / "src/native_qsort_kernel.cpp"}"',f'/Fe"{out / "qsort_probe.exe"}"','/link','/MANIFEST:EMBED'])+'\n')
batch=out/'compile.cmd'
batch.write_text(f'@echo off\ncall "{vs / "VC/Auxiliary/Build/vcvarsall.bat"}" x86 >nul\nif errorlevel 1 exit /b %errorlevel%\ncl.exe @"{rsp}"\nexit /b %errorlevel%\n')
with (out/'compile.log').open('w') as log:
    subprocess.run(['cmd','/d','/c',str(batch)],cwd=out,stdout=log,stderr=subprocess.STDOUT,check=True)
exe=Path(json.loads((root/'config/target.json').read_text())['binary'])
result=subprocess.run([str(out/'qsort_probe.exe'),str(exe)],cwd=out,text=True,capture_output=True)
manifest=dict(returncode=result.returncode,stdout=result.stdout,stderr=result.stderr,compiler=str(vs),inputs={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (exe,root/'local/oct18b_qsort_probe.cpp',root/'src/native_qsort_kernel.cpp',Path('C:/Windows/SysWOW64/ucrtbase.dll'))},notes=['Original unchanged BFBE50..BFC5F6 code copied; internal relative calls preserved. Only valid inputs and original comparison callbacks replaced by controlled pointer-key comparators.','Cloud-style finite float difference truncated to integer and sound-style finite sign comparator; n=7 and12 cover cutoff8 boundary. Output and comparator identity sequence checked. Not game validation or exhaustive comparator/range equivalence.'])
(out/'result.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
raise SystemExit(result.returncode)
