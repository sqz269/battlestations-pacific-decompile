@echo off
call "C:\Program Files\Microsoft Visual Studio\18\Community\VC\Auxiliary\Build\vcvarsall.bat" x86 >nul
if errorlevel 1 exit /b %errorlevel%
cl.exe @"J:\PROG\battlestations-pacific-decompile-oct18b-libA\local\output\oct18b-qsort-probe\qsort-probe.rsp"
exit /b %errorlevel%
